<section class="cMain__cont--subs box section-wrapper">
	<div class="cMain__cont--subs--c">
		<div class="cMain__cont--subs--c--cT">
			<h2 class="cMain__cont--subs--c--cT--title">Subscríbete para obtener ofertas especiales</h2>
			<p class="cMain__cont--subs--c--cT--desc">¡No te pierdas la oportunidad!</p>
		</div>
		<form class="cMain__cont--subs--c--cF">
			<div class="cMain__cont--subs--c--cF--control">
				<input type="text" class="cMain__cont--subs--c--cF--control--input" placeholder="Ingresa tu email">
				<button type="submit" class="cMain__cont--subs--c--cF--control--btnsend">Suscribrme</button>
			</div>
		</form>
	</div>
</section>