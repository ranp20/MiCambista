<div class="cListDetailsTransactions">
	<div class="cListDetailsTransactions--contDetails">
		<div>
			<span>
				<span>
					<span>
						<input type="hidden" class='non-visvalipt h-alternative-shwnon s-fkeynone-step' autocomplete='off' spellcheck='false' id="ipt-idClientValListTransac" value="<?= $_SESSION['cli_sessmemopay'][0]['id']; ?>">
					</span>
				</span>
			</span>
		</div>
		<div class="cListDetailsTransactions--contDetails--iconclose" id="btnCloseTransacRight">
			<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
		</div>
		<div class="cListDetailsTransactions--contDetails--c" id="c-detailTransacCli"></div>
		<a href="javascript:void(0);" class="cListDetailsTransactions--contDetails--c--btnclose">Aceptar</a>
	</div>
</div>