<a href="https://api.whatsapp.com/send?phone=51<?= $g_setting("whatsapp_phone")['setting_value']; ?>&text=<?= $g_setting("whatsapp_text")['setting_value']; ?>" class="float" target="_blank" id="chat_wstp-icon">
	<img src="./views/assets/img/icons/whatsapp_api.svg" alt="Contáctanos_por_whatsapp" width="100" height="100" decoding="async">
</a>