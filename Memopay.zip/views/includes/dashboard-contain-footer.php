<div class="cControlP__cont--containDash--cFooter">
	<div class="cControlP__cont--containDash--cFooter--c">
		<h3 class="cControlP__cont--containDash--cFooter--c--title">¡Importante!</h3>
		<ul class="cControlP__cont--containDash--cFooter--c--m">
			<li class="cControlP__cont--containDash--cFooter--c--m--item">
				<div class="cControlP__cont--containDash--cFooter--c--m--item__cIcon">
					<img src="<?= $url ?>views/assets/img/svg/arrows-welcome-footer.svg" alt="">
				</div>
				<p>Recibimos solo transferencias. <br> No aceptamos depósitos.</p>
			</li>
			<li class="cControlP__cont--containDash--cFooter--c--m--item">
				<div class="cControlP__cont--containDash--cFooter--c--m--item__cIcon">
					<img src="<?= $url ?>views/assets/img/svg/user-welcome-footer.svg" alt="">
				</div>
				<p>Recibimos solo transferencias. <br> No aceptamos depósitos.</p>
			</li>
			<li class="cControlP__cont--containDash--cFooter--c--m--item">
				<div class="cControlP__cont--containDash--cFooter--c--m--item__cIcon">
					<img src="<?= $url ?>views/assets/img/svg/clock-welcome-footer.svg" alt="">
				</div>
				<p>Recibimos solo transferencias. <br> No aceptamos depósitos.</p>
			</li>
			<li class="cControlP__cont--containDash--cFooter--c--m--item">
				<div class="cControlP__cont--containDash--cFooter--c--m--item__cIcon">
					<img src="<?= $url ?>views/assets/img/svg/dollar-welcome-footer.svg" alt="">
				</div>
				<p>Recibimos solo transferencias. <br> No aceptamos depósitos.</p>
			</li>
		</ul>
	</div>
</div>